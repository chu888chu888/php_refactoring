<?php

class Dao
{
    public function __construct($host, $user, $pass, $dbname)
    {
    }

    public function fetchAll($sql)
    {
        return array();
    }

    public function fetchRow($table, $where)
    {
        return array();
    }

    public function insert($table, $data)
    {
    }

    public function update($table, $data, $where)
    {
    }

    public function delete($table, $where)
    {
    }
}